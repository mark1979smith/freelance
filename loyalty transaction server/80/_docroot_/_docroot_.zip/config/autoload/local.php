<?php
return array(
		'db' => array(
				'username' => 'loyalty',
				'password' => '',
		),
);