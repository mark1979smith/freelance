<?php
namespace Application\Controller;

use Zend\Mvc\Controller\AbstractActionController;
use Zend\Debug\Debug;
use Application\Model\Transaction;
use Application\Model\View;
use Zend\I18n\Validator\DateTime;
use Application\Model\Customer;
use Zend\Log\Logger;
use Zend\Log\Writer\Stream;
class TransactionController extends AbstractActionController 
{
	// General Response Codes
	const RESPONSE_CODE_SUCCESS						= 0;

	// Define Response Codes
	const RESPONSE_CODE_NOT_ENOUGH_PURCHASE_POINTS 	= 1;
	const RESPONSE_CODE_NOT_ENOUGH_LOYALTY_POINTS	= 2;
	const RESPONSE_CODE_INCORRECT_OTP				= 3;
	const RESPONSE_CODE_TRANSACTION_FAILED			= 4;
	const RESPONSE_CODE_UNKNOWN_TRANSACTION_TYPE	= 5;
	const RESPONSE_CODE_NO_TYPE_MENTIONED			= 6;
	const RESPONSE_CODE_ORDER_CUSTOMER_MISMATCH		= 7;
	const RESPONSE_CODE_PRODUCT_NOT_FOUND_IN_INV	= 8;
	const RESPONSE_CODE_SERVER_ERROR				= 9;
	const RESPONSE_CODE_SALES_TRANSACTION_SUCCESS	= 10;
	const RESPONSE_CODE_RETURN_TRANSACTION_SUCCESS	= 11;
	const RESPONSE_CODE_INVOICE_NUMER_EXISTS		= 12;
	
	
	public function indexAction()
	{
		$this->getResponse()->setStatusCode(404);
		return;
	}
	
	/**
	 * Create a new Transaction
	 */
	public function defineAction()
	{
		// Instatiate Transaction Model
		$transaction = new Transaction();
		
		// Instantiate Customer Model
		$customer = new Customer();
		
		// Instatiate View Model
		$view = new View();
		
		// Assign Fields
		$headers = $_REQUEST['data']['Header'];
		$items = $_REQUEST['data']['Items'];
		$tenders = $_REQUEST['data']['Tenders'];
		
		// Assign Response Codes
		$responseCodes = array(
				self::RESPONSE_CODE_SALES_TRANSACTION_SUCCESS	=> 200,
				self::RESPONSE_CODE_RETURN_TRANSACTION_SUCCESS	=> 600,
				self::RESPONSE_CODE_NOT_ENOUGH_PURCHASE_POINTS 	=> 402,
				self::RESPONSE_CODE_NOT_ENOUGH_LOYALTY_POINTS	=> 403,
				self::RESPONSE_CODE_INCORRECT_OTP				=> 404,
				self::RESPONSE_CODE_TRANSACTION_FAILED			=> 406,
				self::RESPONSE_CODE_UNKNOWN_TRANSACTION_TYPE	=> 500,
				self::RESPONSE_CODE_NO_TYPE_MENTIONED			=> 501,
				self::RESPONSE_CODE_ORDER_CUSTOMER_MISMATCH		=> 502,
				self::RESPONSE_CODE_PRODUCT_NOT_FOUND_IN_INV	=> 503,
				self::RESPONSE_CODE_SERVER_ERROR				=> 504,
				self::RESPONSE_CODE_INVOICE_NUMER_EXISTS		=> 410,
		);
		 
		// Assign Response Messages
		$responseMessages = array(
				self::RESPONSE_CODE_SALES_TRANSACTION_SUCCESS	=> 'Sales Transaction successful',
				self::RESPONSE_CODE_RETURN_TRANSACTION_SUCCESS	=> 'Return Transaction successful',
				self::RESPONSE_CODE_NOT_ENOUGH_PURCHASE_POINTS 	=> 'Not  enough purchase points. Minimum 25 purchase points must be present for loyalty points redemption',
				self::RESPONSE_CODE_NOT_ENOUGH_LOYALTY_POINTS	=> 'Not  enough loyalty points. Minimum 25 loyalty points must be present for loyalty points redemption',
				self::RESPONSE_CODE_INCORRECT_OTP				=> 'Incorrect OTP',
				self::RESPONSE_CODE_TRANSACTION_FAILED			=> 'Transaction failed due to server error',
				self::RESPONSE_CODE_UNKNOWN_TRANSACTION_TYPE	=> 'Unknown Transaction type',
				self::RESPONSE_CODE_NO_TYPE_MENTIONED			=> 'No  Type Mentioned',
				self::RESPONSE_CODE_ORDER_CUSTOMER_MISMATCH		=> 'Order-Customer mismatch',
				self::RESPONSE_CODE_PRODUCT_NOT_FOUND_IN_INV	=> 'Product not found in Invoice',
				self::RESPONSE_CODE_SERVER_ERROR				=> 'Server Error',
				self::RESPONSE_CODE_INVOICE_NUMER_EXISTS		=> 'Invoice Number already exists',
		);
		
		// Instantiate Logger
		$logger = new Logger();
		$stream = @fopen('data/logs/Transaction.log', 'a', false);
		if (! $stream) {
			$view->setResponseCode($responseCodes[self::RESPONSE_CODE_SERVER_ERROR])
				->setResponseMessage($responseMessages[self::RESPONSE_CODE_SERVER_ERROR]);
			return $view->dispatch();
		}
		$writer = new Stream('data/logs/Transaction.log');
		$logger->addWriter($writer);
		$logger->debug($_SERVER['REQUEST_URI']);
		
		/**
		 * Start Validation
		 */
		$transaction->validate($_REQUEST['data'], $customer, $responseCodes, $responseMessages, $view, $logger, $this->getServiceLocator());
		
		// Create the transaction
		$status = $transaction->create($this->getServiceLocator(), $_REQUEST['data']);
		$logger->debug('Created Transaction - Status is ' . (int) $status);
		if ($status === true)
		{
			// Define Points Earned
			$pointsEarned = 0;
			
			// If a SALE transaction
			if (strcasecmp($headers['Type'], 'sales') === 0)
			{
				$view->setResponseCode($responseCodes[self::RESPONSE_CODE_SALES_TRANSACTION_SUCCESS])
					->setResponseMessage($responseMessages[self::RESPONSE_CODE_SALES_TRANSACTION_SUCCESS]);
				
				$pointsEarned = floor($headers['amount']/10000);
			}
			// Else if a RETURN transaction
			elseif (strcasecmp($headers['Type'], 'return') === 0)
			{
				$view->setResponseCode($responseCodes[self::RESPONSE_CODE_RETURN_TRANSACTION_SUCCESS])
					->setResponseMessage($responseMessages[self::RESPONSE_CODE_RETURN_TRANSACTION_SUCCESS]);
			}
			
			if (!is_null($view->getResponseCode()))
			{
				$view->setData(array('docno' => $headers['docno'], 'orderid' => '0', 'pointsearned' => $pointsEarned));
				return $view->dispatch();
			}
		}
		else
		{
			$view->setResponseCode($responseCodes[self::RESPONSE_CODE_SERVER_ERROR])
				->setResponseMessage($responseMessages[self::RESPONSE_CODE_SERVER_ERROR]);
			return $view->dispatch();
		}
	}
	
	public function bulkAction()
	{
		// Instatiate Transaction Model
		$transaction = new Transaction();
		
		// Instantiate Customer Model
		$customer = new Customer();
		
		// Instatiate View Model
		$view = new View();
		
		// Assign Response Codes
		$responseCodes = array(
				self::RESPONSE_CODE_SALES_TRANSACTION_SUCCESS	=> 200,
				self::RESPONSE_CODE_RETURN_TRANSACTION_SUCCESS	=> 600,
				self::RESPONSE_CODE_NOT_ENOUGH_PURCHASE_POINTS 	=> 402,
				self::RESPONSE_CODE_NOT_ENOUGH_LOYALTY_POINTS	=> 403,
				self::RESPONSE_CODE_INCORRECT_OTP				=> 404,
				self::RESPONSE_CODE_TRANSACTION_FAILED			=> 406,
				self::RESPONSE_CODE_UNKNOWN_TRANSACTION_TYPE	=> 500,
				self::RESPONSE_CODE_NO_TYPE_MENTIONED			=> 501,
				self::RESPONSE_CODE_ORDER_CUSTOMER_MISMATCH		=> 502,
				self::RESPONSE_CODE_PRODUCT_NOT_FOUND_IN_INV	=> 503,
				self::RESPONSE_CODE_SERVER_ERROR				=> 504,
				self::RESPONSE_CODE_INVOICE_NUMER_EXISTS		=> 410,
		);
		
		// Assign Response Messages
		$responseMessages = array(
				self::RESPONSE_CODE_SALES_TRANSACTION_SUCCESS	=> 'Bulk Transaction successful',
				self::RESPONSE_CODE_RETURN_TRANSACTION_SUCCESS	=> 'Return Transaction successful',
				self::RESPONSE_CODE_NOT_ENOUGH_PURCHASE_POINTS 	=> 'Not  enough purchase points. Minimum 25 purchase points must be present for loyalty points redemption',
				self::RESPONSE_CODE_NOT_ENOUGH_LOYALTY_POINTS	=> 'Not  enough loyalty points. Minimum 25 loyalty points must be present for loyalty points redemption',
				self::RESPONSE_CODE_INCORRECT_OTP				=> 'Incorrect OTP',
				self::RESPONSE_CODE_TRANSACTION_FAILED			=> 'Transaction failed due to server error',
				self::RESPONSE_CODE_UNKNOWN_TRANSACTION_TYPE	=> 'Unknown Transaction type',
				self::RESPONSE_CODE_NO_TYPE_MENTIONED			=> 'No  Type Mentioned',
				self::RESPONSE_CODE_ORDER_CUSTOMER_MISMATCH		=> 'Order-Customer mismatch',
				self::RESPONSE_CODE_PRODUCT_NOT_FOUND_IN_INV	=> 'Product not found in Invoice',
				self::RESPONSE_CODE_SERVER_ERROR				=> 'Server Error',
				self::RESPONSE_CODE_INVOICE_NUMER_EXISTS		=> 'Invoice Number already exists',
		);
			
		// Instantiate Logger
		$logger = new Logger();
		$stream = @fopen('data/logs/Transaction.log', 'a', false);
		if (! $stream) {
			$view->setResponseCode($responseCodes[self::RESPONSE_CODE_SERVER_ERROR])
			->setResponseMessage($responseMessages[self::RESPONSE_CODE_SERVER_ERROR]);
			return $view->dispatch();
		}
		$writer = new Stream('data/logs/Transaction.log');
		$logger->addWriter($writer);
		$logger->debug($_SERVER['REQUEST_URI']);

		if (!array_key_exists('data', $_REQUEST))
		{
			$view->setResponseCode($responseCodes[self::RESPONSE_CODE_SALES_TRANSACTION_SUCCESS])
				->setResponseMessage($responseMessages[self::RESPONSE_CODE_SALES_TRANSACTION_SUCCESS])
				->setData(array());
			return $view->dispatch();
		}
		
		foreach($_REQUEST['data'] as $data)
		{
			// Assign Fields
			$headers = $data['Header'];
			
			/**
			 * Start Validation
			 */
			$transaction->validate($data, $customer, $responseCodes, $responseMessages, $view, $logger, $this->getServiceLocator());
			
			// Create the transaction
			$status = $transaction->create($this->getServiceLocator(), $data);
			$logger->debug('Created Transaction - Status is ' . (int) $status);
			if ($status === true)
			{
				// Define Points Earned
				$pointsEarned = 0;
				
				// If a SALE transaction
				if (strcasecmp($headers['Type'], 'sales') === 0)
				{
					$view->setResponseCode($responseCodes[self::RESPONSE_CODE_SALES_TRANSACTION_SUCCESS])
						->setResponseMessage($responseMessages[self::RESPONSE_CODE_SALES_TRANSACTION_SUCCESS]);
					
					$pointsEarned = floor($headers['amount']/10000);
				}
				// Else if a RETURN transaction
				elseif (strcasecmp($headers['Type'], 'return') === 0)
				{
					$view->setResponseCode($responseCodes[self::RESPONSE_CODE_RETURN_TRANSACTION_SUCCESS])
						->setResponseMessage($responseMessages[self::RESPONSE_CODE_RETURN_TRANSACTION_SUCCESS]);
				}
				
				if (!is_null($view->getResponseCode()))
				{
					$view->addData(array('docno' => $headers['docno'], 'orderid' => '0', 'pointsearned' => $pointsEarned));
					return $view->dispatch();
				}
			}
			else
			{
				$view->setResponseCode($responseCodes[self::RESPONSE_CODE_SERVER_ERROR])
					->setResponseMessage($responseMessages[self::RESPONSE_CODE_SERVER_ERROR]);
				return $view->dispatch();
			}
		}
	}
	
	public function retrieveAction()
	{
		
	}
	
	public function historyAction()
	{
		
	}
}

?>