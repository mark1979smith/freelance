<?php
namespace Application\Model;

use Zend\ServiceManager\ServiceManager;
use Zend\Stdlib\Parameters;
use Zend\Db\Sql\Sql;
use Zend\Db\Sql\Expression;
use Zend\Debug\Debug;
use Zend\Log\Logger;
use Zend\Log\Writer\Stream;
use Application\Controller\TransactionController;

/**
 * This class is anything to do with transactions
 */
class Transaction
{
	const DB_TABLE_TRANSACTIONS			= 'transactions';
	const DB_TABLE_TRANSACTIONS_ITEMS	= 'transactions_items';
	const DB_TABLE_TRANSACTIONS_TENDERS	= 'transactions_tenders';
	const DB_TABLE_CUSTOMERS			= 'customers';
	const MAX_RESULTS = 250;
	
	public function create(ServiceManager $sm, $data)
	{
		// Log the request
		$logger = new Logger();
		$stream = @fopen('data/logs/Transaction.log', 'a', false);
		if (! $stream) {
			throw new \Exception('Failed to open stream');
		}
		$writer = new Stream('data/logs/Transaction.log');
		$logger->addWriter($writer); 
		$logger->debug('create()');
		
		// Normalise Data
		$data = new Parameters($data);

		// Define new Database call
		$sql = new Sql($sm->get('db'));
		
		// Get the database connection so we can manage the transaction
		$connection = $sm->get('db')->getDriver()->getConnection();
		// Begin Transaction
		$connection->beginTransaction();
		try {
			// Insert into transactions table
			$insert = $sql->insert();
			$insert->into(self::DB_TABLE_TRANSACTIONS)
				->values(array_merge($data->toArray()['Header'], array('datetime' => date('Y-m-d H:i:s', strtotime($data->toArray()['Header']['datetime'])))));
			$statement = $sql->prepareStatementForSqlObject($insert);
			$affectedRows = $statement->execute()->getAffectedRows();
			if ($affectedRows == 0)
			{
				$connection->rollback();
				return false;
			}
			
			// Insert into transaction items table
			foreach($data->toArray()['Items'] as $key => $itemRow)
			{
				$insert = $sql->insert();
				$insert->into(self::DB_TABLE_TRANSACTIONS_ITEMS)
					->values(array_merge($itemRow, array('docno' => $data->toArray()['Header']['docno'], 'row' => $key)));
				$statement = $sql->prepareStatementForSqlObject($insert);
				$affectedRows = $statement->execute()->getAffectedRows();
				if ($affectedRows == 0)
				{
					$connection->rollback();
					return false;
				}
			}
			
			// Insert into transaction tenders table
			foreach($data->toArray()['Tenders'] as $key => $tenderRow)
			{
				$insert = $sql->insert();
				$insert->into(self::DB_TABLE_TRANSACTIONS_TENDERS)
					->values(array_merge($tenderRow, array('docno' => $data->toArray()['Header']['docno'], 'row' => $key)));
				$statement = $sql->prepareStatementForSqlObject($insert);
				$affectedRows = $statement->execute()->getAffectedRows();
				if ($affectedRows == 0)
				{
					$connection->rollback();
					return false;
				}
			}
						
			// Commit the transaction
			$connection->commit();
		}
		catch(\Exception $e)
		{
			$connection->rollback();
			return false;
		}
		
		// If we get this far - the transaction was successful
		// If Sales we need to add the loyalty points
		if (strcasecmp($data->toArray()['Header']['Type'], 'sales') === 0)
		{
			// Get existing Loyalty Points
			$customer = new Customer();
			$customerPoints = $customer->read($sm, array('customerid' => $data->toArray()['Header']['customerid']), array('points'));
		
			$customer->update($sm, $data->toArray()['Header']['customerid'], 
				array(
					'points' => new Expression(
						$customerPoints->current()['points'] .' + '. 
						floor($data->toArray()['Header']['amount']/10000)
					)
				)
			);
		}
		
		return true;
	}
	
	
	public function read(ServiceManager $sm, $table, $filter, $fields = NULL)
	{
		// Enforce Array of $data
		$filter = new Parameters($filter);
		
		// Define new Database call
		$sql = new Sql($sm->get('db'));
		
		// Define SQL Statement
		$select = $sql->select();
		$select
			->from($table)
			->where($filter->toArray())
			->limit(self::MAX_RESULTS);
			
		// Add Fields if needed
		if (is_array($fields))
		{
			$select->columns($fields);
		}
		
		// Run Query
		$statement = $sql->prepareStatementForSqlObject($select);
		
		// Return RowSet
		return $statement->execute();
		
	}
	
	public function delete()
	{
		throw new \Exception('Not implemented yet');
	}
	
	/**
	 * Validate the transactions
	 * @param array $data
	 * @param Customer $customer
	 * @param array $responseCodes
	 * @param array $responseMessages
	 * @param View $view
	 * @param Logger $logger
	 * @param ServiceManager $sm
	 */
	public function validate($data, $customer, $responseCodes, $responseMessages, $view, $logger, $sm)
	{
		// Assign Fields
		if (array_key_exists('Header', $data))
			$headers = $data['Header'];
		else 
			$headers = array();
		if (array_key_exists('Items', $data))
			$items = $data['Items'];
		else 
			$items = array();
		if (array_key_exists('Tenders', $data))
			$tenders = $data['Tenders'];
		else 
			$tenders = array();
		
		// Validate Doc No is unique
		$docNo = $this->read($sm, self::DB_TABLE_TRANSACTIONS, array('docno' => $headers['docno']));
		if (count($docNo) > 0)
		{
			$logger->debug('Invoice Number Exists');
			$view->setResponseCode($responseCodes[TransactionController::RESPONSE_CODE_INVOICE_NUMER_EXISTS])
			->setResponseMessage($responseMessages[TransactionController::RESPONSE_CODE_INVOICE_NUMER_EXISTS]);
			return $view->dispatch();
		}
		
		// Validate Date/Time
		if (strtotime($headers['datetime']) === false)
		{
			$logger->debug('Date Time cannot be parsed by strtotime()');
			$view->setResponseCode($responseCodes[TransactionController::RESPONSE_CODE_SERVER_ERROR])
			->setResponseMessage($responseMessages[TransactionController::RESPONSE_CODE_SERVER_ERROR]);
			return $view->dispatch();
		}
		
		// Validate Type Exists
		if (!array_key_exists('Type', $headers))
		{
			$logger->debug('Type not set');
			$view->setResponseCode($responseCodes[TransactionController::RESPONSE_CODE_NO_TYPE_MENTIONED])
			->setResponseMessage($responseMessages[TransactionController::RESPONSE_CODE_NO_TYPE_MENTIONED]);
			return $view->dispatch();
		}
		
		// Validate Customer Id
		if (strlen($headers['customerid']) == 0)
		{
			$logger->debug('Customer Id is empty');
			$view->setResponseCode($responseCodes[TransactionController::RESPONSE_CODE_SERVER_ERROR])
			->setResponseMessage($responseMessages[TransactionController::RESPONSE_CODE_SERVER_ERROR]);
			return $view->dispatch();
		}
		
		$customerRecord = $customer->read($sm, array('customerid' => $headers['customerid']));
		if (count($customerRecord) == 0)
		{
			$logger->debug('Customer ID: ' . $headers['customerid'] .' does not exist');
			$view->setResponseCode($responseCodes[TransactionController::RESPONSE_CODE_ORDER_CUSTOMER_MISMATCH])
			->setResponseMessage($responseMessages[TransactionController::RESPONSE_CODE_ORDER_CUSTOMER_MISMATCH]);
			return $view->dispatch();
		}
		
		// Validate Mobile Number
		if (strlen($headers['mobileno']) > 0)
		{
			// Check Mobile Number is required length
			if (strlen($headers['mobileno']) <> 10)
			{
				$logger->debug('Mobile Number: '. $headers['mobileno'] .' is not 10 digits');
				$view->setResponseCode($responseCodes[$customer::RESPONSE_CODE_MOBILE_LENGTH_FAIL])
				->setResponseMessage($responseMessages[$customer::RESPONSE_CODE_MOBILE_LENGTH_FAIL]);
				return $view->dispatch();
			}
			// Check Mobile Number is required regexp
			if (preg_match('/^[7-9]/', $headers['mobileno']) === 0)
			{
				$logger->debug('Mobile Number: ' . $headers['mobileno'] .' does not match regexp');
				$view->setResponseCode($responseCodes[$customer::RESPONSE_CODE_MOBILE_REGEXP_FAIL])
				->setResponseMessage($responseMessages[$customer::RESPONSE_CODE_MOBILE_REGEXP_FAIL]);
				return $view->dispatch();
			}
			// Check Mobile Number exists in system
			$mobileNumberRecord = $customer->read($sm, array('mobileno' => $headers['mobileno']));
			if (count($mobileNumberRecord) == 0)
			{
				$logger->debug('Mobile Number: '. $headers['mobileno'] .' does not exist in customer database table');
				$view->setResponseCode($responseCodes[TransactionController::RESPONSE_CODE_ORDER_CUSTOMER_MISMATCH])
				->setResponseMessage($responseMessages[TransactionController::RESPONSE_CODE_ORDER_CUSTOMER_MISMATCH]);
				return $view->dispatch();
			}
		}
		
		// Validate Sales Type
		if (strcasecmp($headers['Type'], 'sales') === 0)
		{
			// Ensure Redeem Points exist
			if ((array_key_exists('redeempoints', $headers) && strlen($headers['redeempoints']) == 0) || !array_key_exists('redeempoints', $headers))
			{
				$logger->debug('Redeem Points is not set or is empty');
				$view->setResponseCode($responseCodes[TransactionController::RESPONSE_CODE_SERVER_ERROR])
				->setResponseMessage($responseMessages[TransactionController::RESPONSE_CODE_SERVER_ERROR]);
				return $view->dispatch();
			}
				
			// Ensure Amount exists
			/*if ((array_key_exists('amount', $headers) && strlen($headers['amount']) == 0) || !array_key_exists('amount', $headers))
			 {
			$view->setResponseCode($responseCodes[TransactionController::RESPONSE_CODE_SERVER_ERROR])
			->setResponseMessage($responseMessages[TransactionController::RESPONSE_CODE_SERVER_ERROR]);
			return $view->dispatch();
			}*/
		}
		
		// Validate OTP
		if (array_key_exists('redeempoints', $headers) && $headers['redeempoints'] == 1)
		{
			if ((!array_key_exists('otp', $headers) && strlen($headers['otp']) <> 6) || !array_key_exists('otp', $headers))
			{
				$logger->debug('OTP either does not exist or is not correct');
				$view->setResponseCode($responseCodes[TransactionController::RESPONSE_CODE_SERVER_ERROR])
				->setResponseMessage($responseMessages[TransactionController::RESPONSE_CODE_SERVER_ERROR]);
				return $view->dispatch();
			}
		}
		
		// Validate Payment mode
		foreach($tenders as $tenderRow)
		{
			if(!in_array($tenderRow['paymentmode'], array(
					'cod', // Cash
					'clp', // Credit Loyalty Points
					'gv', // Gift Voucher
					'gc', // Gift Card
			)))
			{
				$logger->debug('PaymentMode: '. $tenderRow['paymentmode'] .' is not one of COD, CLP, GV, GC');
				$view->setResponseCode($responseCodes[TransactionController::RESPONSE_CODE_SERVER_ERROR])
				->setResponseMessage($responseMessages[TransactionController::RESPONSE_CODE_SERVER_ERROR]);
				return $view->dispatch();
			}
		}
	}
	
	
}